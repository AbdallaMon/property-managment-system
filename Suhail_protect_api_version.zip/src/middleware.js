import {NextResponse} from 'next/server';
import {cookies} from 'next/headers';

export function middleware(request) {
    console.error('Middleware hit');

    const cookieStore = cookies();
    console.error('Cookies:', cookieStore);

    const cookieValue = cookieStore.get("token")?.value;
    console.error('cookieValue:', cookieValue);

    if (!cookieValue) {
        console.error('Redirecting to unauthorized');
        return NextResponse.redirect(new URL('/api/unauthorized', request.url));
    }

    console.error('Proceeding to next response');
    return NextResponse.next();
}

export const config = {
    matcher: ['/api/main/:path*'],
};
