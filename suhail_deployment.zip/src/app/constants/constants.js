export const paginationOptions = [20, 30, 40, 50];
export const initialPageLimit = 20;
