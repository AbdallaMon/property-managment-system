import {NextResponse} from 'next/server';
import {cookies} from 'next/headers';
import {jwtVerify} from 'jose';

export async function middleware(request) {

    const SECRET_KEY = new TextEncoder().encode(process.env.SECRET_KEY);
    const cookieStore = cookies();

    const token = cookieStore.get("token")?.value;

    if (!token) {
        console.error('Redirecting to unauthorized: No token found');
        return NextResponse.redirect(new URL('/api/unauthorized', request.url));
    }

    try {
        const {payload} = await jwtVerify(token, SECRET_KEY);
        if (!payload) {
            throw new Error("error")
        }
        return NextResponse.next();
    } catch (error) {
        console.error(error)
        return NextResponse.redirect(new URL('/api/unauthorized', request.url));
    }
}

export const config = {
    matcher: ['/api/main/:path*'],
};
